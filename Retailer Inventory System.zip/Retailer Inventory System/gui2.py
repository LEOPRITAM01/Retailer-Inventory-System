import sqlite3
from tkinter import *
from tkinter import messagebox

# Connect to the SQLite database
conn = sqlite3.connect('user_data.db')
cursor = conn.cursor()

# Function to verify user credentials
def verify_login():
    user_id = entry_id.get()
    password = entry_password.get()

    # Fetch user details from the database
    cursor.execute('SELECT * FROM users WHERE id = ? AND password = ?', (user_id, password))
    result = cursor.fetchone()

    if result:
        open_success_window()  # If valid credentials, open a success window
    else:
        messagebox.showerror("Login Failed", "Invalid User ID or Password")

# Function to open a success window with additional options
def open_success_window():
    success_window = Toplevel(root)
    success_window.title("Dashboard")
    success_window.geometry("400x300")
    
    Label(success_window, text="Login Successful!", font=("Helvetica", 16)).pack(pady=10)
    
    # Add buttons for the requested functionalities
    Button(success_window, text="Add Items", font=("Helvetica", 12), command=add_items).pack(pady=5)
    Button(success_window, text="Update Pricing and Quantity", font=("Helvetica", 12), command=update_pricing_quantity).pack(pady=5)
    Button(success_window, text="Generate Bill", font=("Helvetica", 12), command=open_generate_bill_window).pack(pady=5)

# Functions for the options (placeholders)
def add_items():
    messagebox.showinfo("Add Items", "Add items functionality triggered.")

def update_pricing_quantity():
    messagebox.showinfo("Update Pricing and Quantity", "Update pricing and quantity functionality triggered.")

# Function to open the "Generate Bill" window with form inputs
def open_generate_bill_window():
    bill_window = Toplevel(root)
    bill_window.title("Generate Bill")
    bill_window.geometry("500x500")
    
    # Title of the window
    Label(bill_window, text="Generate Bill", font=("Helvetica", 16)).pack(pady=10)

    # Item Name, Quantity, Price Entry
    Label(bill_window, text="Item Name:", font=("Helvetica", 12)).pack(pady=5)
    item_name_entry = Entry(bill_window, font=("Helvetica", 12))
    item_name_entry.pack(pady=5)

    Label(bill_window, text="Quantity:", font=("Helvetica", 12)).pack(pady=5)
    quantity_entry = Entry(bill_window, font=("Helvetica", 12))
    quantity_entry.pack(pady=5)

    Label(bill_window, text="Price per Item:", font=("Helvetica", 12)).pack(pady=5)
    price_entry = Entry(bill_window, font=("Helvetica", 12))
    price_entry.pack(pady=5)

    # Listbox to display the added items
    item_listbox = Listbox(bill_window, font=("Helvetica", 12), width=40, height=10)
    item_listbox.pack(pady=10)

    # Label to show the total bill
    total_label = Label(bill_window, text="Total Bill: $0.00", font=("Helvetica", 14, "bold"))
    total_label.pack(pady=10)

    # Function to calculate and update the total bill
    def calculate_total():
        try:
            # Get input values
            item_name = item_name_entry.get()
            quantity = int(quantity_entry.get())
            price = float(price_entry.get())

            # Calculate the total for this item
            total_item_price = quantity * price

            # Update the listbox to show item details
            item_listbox.insert(END, f"{item_name} - Quantity: {quantity} - Price: ${total_item_price:.2f}")

            # Calculate the updated total bill
            total_amount = sum([float(entry.split(": $")[-1]) for entry in item_listbox.get(0, END)])
            total_label.config(text=f"Total Bill: ${total_amount:.2f}")

            # Clear the input fields for next entry
            item_name_entry.delete(0, END)
            quantity_entry.delete(0, END)
            price_entry.delete(0, END)

        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid quantities and prices.")

    # Add item button to add the item to the listbox and calculate total
    add_item_button = Button(bill_window, text="Add Item", font=("Helvetica", 12), command=calculate_total)
    add_item_button.pack(pady=10)

# Main window
root = Tk()
root.title("Login Page")
root.geometry("400x200")

# User ID Label and Entry
Label(root, text="User ID:", font=("Helvetica", 12)).pack(pady=5)
entry_id = Entry(root)
entry_id.pack(pady=5)

# Password Label and Entry
Label(root, text="Password:", font=("Helvetica", 12)).pack(pady=5)
entry_password = Entry(root, show='*')
entry_password.pack(pady=5)

# Login Button
Button(root, text="Login", command=verify_login, font=("Helvetica", 12)).pack(pady=20)

# Run the Tkinter event loop
root.mainloop()

# Close the database connection when the window is closed
conn.close()
